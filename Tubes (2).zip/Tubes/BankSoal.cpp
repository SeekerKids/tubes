#include "User.h"
#include "BankSoal.h"

void createSoalList(ListSoal &L) {
    firstSoal(L) = nilSoal;
}

AdrSoal allocateSoal(InfoSoal x) {
    AdrSoal p = new ElmSoal;
    infoSoal(p) = x;
    nextSoal(p) = nilSoal;
    return p;
}

void insertLastSoal(ListSoal &L, AdrSoal P) {
    if (firstSoal(L) == nilSoal) {
        nextSoal(P) = nilSoal;
        firstSoal(L) = P;
    } else if (nextSoal(firstSoal(L)) == nilSoal) {
        nextSoal(firstSoal(L)) = P;
        nextSoal(P) = nilSoal;
    } else {
        AdrSoal Q = firstSoal(L);
        while (nextSoal(Q) != nilSoal){
            Q = nextSoal(Q);
        }
        nextSoal(Q) = P;
    }
}

int countSoal(ListSoal L) {
    int count = 0;
    AdrSoal P = firstSoal(L);
    while (P != nilSoal) {
        count++;
        P = nextSoal(P);
    }
    return count;
}

void displayAllSoal(ListSoal L) {
    AdrSoal P = firstSoal(L);
    if (P == nilSoal) {
        cout << "Belum ada soal yang tersedia." << endl;
        return;
    }

    while (P != nilSoal) {
        cout << endl;
        cout << "Index : " << infoSoal(P).indexSoal << endl;
        cout << "Pertanyaan:" << endl;
        cout << infoSoal(P).pertanyaan << endl;
        cout << "A. " << infoSoal(P).pilihanA << endl;
        cout << "B. " << infoSoal(P).pilihanB << endl;
        cout << "C. " << infoSoal(P).pilihanC << endl;
        cout << "Jawaban yang benar: " << infoSoal(P).jawaban << endl;
        cout << "---------------------------------" << endl;
        P = nextSoal(P);
    }
}

void addSoal(ListSoal &L){
    AdrSoal Q;
    InfoSoal infoSoal;
    string pertanyaan, pilihanA,pilihanB,pilihanC;
    char jawaban;

    cout << "\n+=============================+" << endl;
    cout << "|        Tambah Soal           |" << endl;
    cout << "+=============================+" << endl;

    cout << "Pertanyaan: ";
    cin >> pertanyaan;
    infoSoal.pertanyaan = pertanyaan;

    cout << "Pilihan A: ";
    cin >> pilihanA;
    cout << "Pilihan B: ";
    cin >> pilihanB;
    cout << "Pilihan C: ";
    cin >> pilihanC;

    cout << "Jawaban: ";
    cin >> jawaban;
    infoSoal.pilihanA = pilihanA;
    infoSoal.pilihanB = pilihanB;
    infoSoal.pilihanC = pilihanC;
    infoSoal.jawaban = jawaban;
    infoSoal.countBenar = 0;
    infoSoal.countSalah = 0;

    infoSoal.indexSoal = countSoal(L)+1;
    Q = allocateSoal(infoSoal);
    insertLastSoal(L, Q);

    cout << "Soal successfully registered!" << endl;
    return;
}

AdrSoal findSoalByIndex(ListSoal L, int index) {
    AdrSoal P  = firstSoal(L);
    while (P != nilSoal) {
        if (infoSoal(P).indexSoal == index) {
            return P;  // Found the user
        }
        P = nextSoal(P);
    }

    return nilSoal;  // User not found

}

void editSoal(ListSoal &L){
    int editIndex;
    AdrSoal Q;
    InfoSoal infoSoal;
    string pertanyaan, pilihanA,pilihanB,pilihanC;
    char jawaban;

    cout << "\n+=============================+" << endl;
    cout << "|          Edit Soal           |" << endl;
    cout << "+=============================+" << endl;
    cout << "Soal dengan index berapa yang ingin di edit : ";
    cin >> editIndex;
    cout << endl;
    AdrSoal x = findSoalByIndex(L, editIndex);
    if (x == nullptr){
        cout << "Tidak ditemukan Soal dengan index tersebut" << endl;
    } else {
        cout << "";
        cout << "Edit Pertanyaan: ";
        cin >> pertanyaan;
        infoSoal(x).pertanyaan = pertanyaan;

        cout << "Edit Pilihan A: ";
        cin >> pilihanA;
        cout << "Edit Pilihan B: ";
        cin >> pilihanB;
        cout << "Edit Pilihan C: ";
        cin >> pilihanC;

        cout << "Edit Jawaban: ";
        cin >> jawaban;
        cout << endl;
        infoSoal(x).pilihanA = pilihanA;
        infoSoal(x).pilihanB = pilihanB;
        infoSoal(x).pilihanC = pilihanC;
        infoSoal(x).jawaban = jawaban;
        cout << "Soal telah Berhasil di Edit"<<endl;
    }

}

void displayTopQuestions(/*ListQuiz L,*/const ListSoal &L) {
    //
    ListSoal tempSoaList;
    createSoalList(tempSoaList);

    AdrSoal P, Q;

    int tempCountBenar;
    int tempCountSalah;
    int tempindex;
    bool swapped;
    bool swappedSalah;

    if (firstSoal(L) == nilSoal || nextSoal(firstSoal(L)) == nilSoal) {
        // No need to sort if there is 1 element or less
        return;
    }

    P = firstSoal(L);
    while (P != nullptr) {
        InfoSoal tempInfo;
        tempInfo.indexSoal = infoSoal(P).indexSoal;
        tempInfo.pertanyaan = infoSoal(P).pertanyaan;
        tempInfo.pilihanA = infoSoal(P).pilihanA;
        tempInfo.pilihanB = infoSoal(P).pilihanB;
        tempInfo.pilihanC = infoSoal(P).pilihanC;
        tempInfo.jawaban = infoSoal(P).jawaban;
        tempInfo.countBenar = infoSoal(P).countBenar;
        tempInfo.countSalah = infoSoal(P).countSalah;

        AdrSoal tempSoal = allocateSoal(tempInfo);
        insertLastSoal(tempSoaList, tempSoal);

        P = nextSoal(P);
    }

    do {
        swapped = false;
        P = firstSoal(tempSoaList);

        while (nextSoal(P) != nullptr) {
            Q = nextSoal(P);

            if (infoSoal(P).countBenar < infoSoal(Q).countBenar) {
                tempCountBenar = infoSoal(P).countBenar;
                tempindex = infoSoal(P).indexSoal;

                infoSoal(P).countBenar = infoSoal(Q).countBenar;
                infoSoal(P).indexSoal = infoSoal(Q).indexSoal;

                infoSoal(Q).countBenar = tempCountBenar;
                infoSoal(Q).indexSoal = tempindex;

                swapped = true;
            }

            P = nextSoal(P);
        }
    } while (swapped);

    // Print the sorted names
    P = firstSoal(tempSoaList);
    int i = 1;
    cout << "+================================+" << endl;
    cout << "| 5 Pertanyaan Paling Sering Benar |" << endl;
    cout << "+================================+" << endl;
    while (P != nullptr && infoSoal(P).countBenar >= 0) {
        cout << "- Index Soal Paling banyak benar " << i << ": " << infoSoal(P).indexSoal << endl;
        cout << infoSoal(P).pertanyaan << endl;
        i++;
        cout << "  Banyak User Benar: " << infoSoal(P).countBenar << endl;
        P = nextSoal(P);
    }
    cout << endl;
    cout<< "------------------------------------------" <<endl;
     do {
        swappedSalah = false;
        P = firstSoal(tempSoaList);

        while (nextSoal(P) != nullptr) {
            Q = nextSoal(P);
            if (infoSoal(P).countSalah < infoSoal(Q).countSalah) {
                tempCountSalah = infoSoal(P).countSalah;
                tempindex = infoSoal(P).indexSoal;

                infoSoal(P).countSalah = infoSoal(Q).countSalah;
                infoSoal(P).indexSoal = infoSoal(Q).indexSoal;

                infoSoal(Q).countSalah = tempCountSalah;
                infoSoal(Q).indexSoal = tempindex;

                swappedSalah = true;
                }

            P = nextSoal(P);
        }
    } while (swappedSalah);

    // Print the sorted names
    P = firstSoal(tempSoaList);
    int iSalah = 1;
    cout << "+================================+" << endl;
    cout << "| 5 Pertanyaan Paling Sering Salah |" << endl;
    cout << "+================================+" << endl;
    while (P != nullptr && infoSoal(P).countSalah >= 0) {
        cout << "- Index Soal Paling banyak benar " << iSalah << ": " << infoSoal(P).indexSoal << endl;
        cout << infoSoal(P).pertanyaan << endl;
        i++;
        cout << "  Banyak User Salah: " << infoSoal(P).countSalah << endl;
        P = nextSoal(P);
    }


}






